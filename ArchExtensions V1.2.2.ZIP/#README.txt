THIS IS THE ARCHEXTN V1.2.2 INSTALL PACKAGE ISSUED APRIL 22,2025
====> note - $README files are EBCDIC   #README files are ASCII <====
This is a complete replacement of ARCHEXTN V1.x.x as well as an
install for ARCHEXTN v1.2.2.

There are two other README items:

- use $README1 if you are using MVS TK5 Update 4 or later
- use $README2 if you are using some other implementation of MVS and
  have the following software installed:
          ARCHIVER 6.1.8 or later
